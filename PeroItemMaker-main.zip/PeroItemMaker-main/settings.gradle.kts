rootProject.name = "PeroItemMaker"

dependencyResolutionManagement {
    repositories {
        maven("https://nexus.phoenixdevt.fr/repository/maven-public/")
        maven("https://maven.hqservice.kr/repository/maven-public")
        maven("https://repo.papermc.io/repository/maven-public/")
        maven("https://mvn.lumine.io/repository/maven-public/")
        maven("https://jitpack.io/")
    }

    versionCatalogs {
        create("libs") {
            library("spigot-api", "org.spigotmc:spigot-api:${getProperty("spigotVersion")}")
            library("paper-api", "io.papermc.paper:paper-api:${getProperty("spigotVersion")}")
            library("mmo-item", "net.Indyuce:MMOItems-API:6.9.2-SNAPSHOT")
            library("mmo-lib", "io.lumine:MythicLib-dist:1.6.2-SNAPSHOT")
            library("londev-ia", "com.github.LoneDev6:api-itemsadder:3.5.0b")
        }
        create("framework") {
            library("core", "kr.hqservice:hqframework-bukkit-core:1.0.0-SNAPSHOT")
            library("command", "kr.hqservice:hqframework-bukkit-command:1.0.0-SNAPSHOT")
            library("nms", "kr.hqservice:hqframework-bukkit-nms:1.0.0-SNAPSHOT")
            library("inventory", "kr.hqservice:hqframework-bukkit-inventory:1.0.0-SNAPSHOT")
            library("coroutine", "kr.hqservice:hqframework-bukkit-coroutine:1.0.0-SNAPSHOT")
            library("database", "kr.hqservice:hqframework-bukkit-database:1.0.0-SNAPSHOT")
        }
    }
}

includeBuild("build-logic")
includeAll("modules")

fun includeAll(modulesDir: String) {
    file("${rootProject.projectDir.path}/${modulesDir.replace(":", "/")}/").listFiles()?.forEach { modulePath ->
        include("${modulesDir.replace("/", ":")}:${modulePath.name}")
    }
}

fun getProperty(key: String): String {
    return extra[key]?.toString() ?: throw IllegalArgumentException("property with $key not found")
}