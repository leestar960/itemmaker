package kr.hqservice.maker.core.registry

import kr.hqservice.maker.core.recipe.Recipe
import org.bukkit.plugin.Plugin
import org.bukkit.util.io.BukkitObjectInputStream
import org.bukkit.util.io.BukkitObjectOutputStream
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import kotlin.reflect.KClass

@Registry
class ItemRecipeRegistry(
    plugin: Plugin
) {
    private val folder: File = File(plugin.dataFolder, "recipe")
    private val cachedRecipeMap = mutableMapOf<String, Recipe<*>>()

    fun loadAll() {
        folder.listFiles()?.forEach { file ->
            ByteArrayInputStream(file.readBytes()).use {
                BukkitObjectInputStream(it).use { stream ->
                    val recipe = Recipe.read(stream)
                    cachedRecipeMap[recipe.getKey()] = recipe
                }
            }
        }
    }

    fun addRecipe(recipe: Recipe<*>) {
        val file = getFile(recipe.getKey(), true)
        file?.apply {
            ByteArrayOutputStream().use {
                BukkitObjectOutputStream(it).use(recipe::writeByteArray)
                writeBytes(it.toByteArray())
            }
        } ?: throw IOException("저장 실패")

        cachedRecipeMap[recipe.getKey()] = recipe
    }

    fun removeRecipe(key: String) {
        cachedRecipeMap.remove(key)
        getFile(key)?.delete()
    }

    fun findByKey(key: String): Recipe<*>? {
        return cachedRecipeMap[key]
    }

    fun getAll(): List<Recipe<*>> {
        return cachedRecipeMap.values.toList()
    }

    fun <E, T: Recipe<E>> getAll(recipeClass: KClass<T>): List<T> {
        return cachedRecipeMap.values.filterIsInstance(recipeClass.java)
    }

    private fun getFile(key: String, create: Boolean = false): File? {
        if (create) if (!folder.exists()) folder.mkdirs()

        return if (folder.exists()) {
            val file = File(folder, "$key.bin")
            if (file.exists()) file
            else if (create) file
            else null
        } else null
    }
}