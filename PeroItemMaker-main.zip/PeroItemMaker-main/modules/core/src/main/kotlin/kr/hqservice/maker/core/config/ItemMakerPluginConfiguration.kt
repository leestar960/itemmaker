package kr.hqservice.maker.core.config

import kr.hqservice.framework.global.core.component.Configuration
import kr.hqservice.framework.global.core.component.Singleton
import net.Indyuce.mmoitems.MMOItems

@Configuration
class ItemMakerPluginConfiguration {
    @Singleton
    fun provideMMOItemsPlugin(): MMOItems {
        return MMOItems.plugin
    }
}