package kr.hqservice.maker.core.recipe

import org.bukkit.inventory.ItemStack
import org.bukkit.util.io.BukkitObjectInputStream
import org.bukkit.util.io.BukkitObjectOutputStream
import kotlin.reflect.full.companionObject

sealed class Recipe<E>(ioReader: IOReader<out Recipe<E>>) {
    companion object {
        fun read(inputStream: BukkitObjectInputStream): Recipe<*> {
            val classQualifiedName = inputStream.readUTF()
            val recipeClass = Class.forName(classQualifiedName).kotlin
            val reader = recipeClass.companionObject?.objectInstance as IOReader<*>
            return reader.read(inputStream)
        }
    }
    private val classQualifiedName = this::class.qualifiedName!!

    abstract fun getKey(): String

    abstract fun getBaseItem(): E?

    abstract fun getBaseItemView(): ItemStack

    abstract fun getResultItemView(): ItemStack

    abstract fun getMaterials(): Array<ItemStack>

    abstract fun getResult(baseItemStack: E? = null): E

    abstract fun write(outputStream: BukkitObjectOutputStream)

    abstract fun getPercent(): Double

    fun writeByteArray(outputStream: BukkitObjectOutputStream) {
        outputStream.writeUTF(classQualifiedName)
        write(outputStream)
    }
}