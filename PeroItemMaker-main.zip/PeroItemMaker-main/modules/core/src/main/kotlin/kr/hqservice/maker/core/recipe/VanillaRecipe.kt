package kr.hqservice.maker.core.recipe

import kr.hqservice.framework.bukkit.core.extension.toByteArray
import kr.hqservice.framework.bukkit.core.extension.toItemArray
import kr.hqservice.maker.core.hook.MMOItemData
import org.bukkit.Material
import org.bukkit.inventory.ItemStack
import org.bukkit.util.io.BukkitObjectInputStream
import org.bukkit.util.io.BukkitObjectOutputStream

class VanillaRecipe(
    private val recipeKey: String,
    private val materials: Array<ItemStack>,
    private val baseItemStack: ItemStack?,
    private val resultItemStack: ItemStack,
    private val percent: Double
) : Recipe<ItemStack>(VanillaRecipe) {
    companion object : IOReader<VanillaRecipe> {
        override fun read(inputStream: BukkitObjectInputStream): VanillaRecipe {
            val key = inputStream.readUTF()
            val baseItemStack: ItemStack? = (inputStream.readObject() as ItemStack).run {
                if (type.isAir) null else this
            }
            val resultItemStack = inputStream.readObject() as ItemStack
            val percent = inputStream.readDouble()
            val materials = inputStream.readBytes().toItemArray()
            return VanillaRecipe(key, materials, baseItemStack, resultItemStack, percent)
        }
    }

    override fun getKey(): String {
        return recipeKey
    }

    override fun getBaseItem(): ItemStack? {
        return null
    }

    override fun getBaseItemView(): ItemStack {
        return baseItemStack?.clone() ?: ItemStack(Material.AIR)
    }

    override fun getResultItemView(): ItemStack {
        return resultItemStack
    }

    override fun getMaterials(): Array<ItemStack> {
        return materials.filter {
            it.type != Material.AIR
        }.toMutableList().apply { baseItemStack?.apply {
            add(this)
        } }.toTypedArray()
    }

    override fun getPercent(): Double {
        return percent
    }

    @Suppress("unchecked_cast")
    override fun write(outputStream: BukkitObjectOutputStream) {
        outputStream.writeUTF(recipeKey)
        outputStream.writeObject(baseItemStack ?: ItemStack(Material.AIR))
        outputStream.writeObject(resultItemStack)
        outputStream.writeDouble(percent)
        outputStream.write((materials as Array<ItemStack?>).toByteArray())
    }

    override fun getResult(baseItemStack: ItemStack?): ItemStack {
        return resultItemStack
    }

    fun clone(
        materials: Array<ItemStack> = getMaterials(),
        base: ItemStack? = baseItemStack,
        result: ItemStack = resultItemStack,
        percent: Double = getPercent()
    ) : VanillaRecipe {
        return VanillaRecipe(recipeKey, materials, base, result, percent)
    }
}