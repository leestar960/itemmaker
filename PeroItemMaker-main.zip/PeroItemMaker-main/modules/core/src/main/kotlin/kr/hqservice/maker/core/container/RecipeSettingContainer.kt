package kr.hqservice.maker.core.container

import kr.hqservice.framework.inventory.button.HQButtonBuilder
import kr.hqservice.framework.inventory.container.HQContainer
import kr.hqservice.maker.core.context.*
import kr.hqservice.maker.core.context.BASE_ITEM_SLOT
import kr.hqservice.maker.core.context.GLASS_SLOTS
import kr.hqservice.maker.core.context.MATERIAL_SLOTS
import kr.hqservice.maker.core.context.RESULT_ITEM_SLOT
import kr.hqservice.maker.core.context.VANILLA_MATERIAL_SLOTS
import kr.hqservice.maker.core.recipe.Recipe
import kr.hqservice.maker.core.recipe.VanillaRecipe
import org.bukkit.Material
import org.bukkit.event.inventory.InventoryCloseEvent
import org.bukkit.inventory.Inventory

class RecipeSettingContainer(
    key: String,
    private val previousRecipe: Recipe<*>? = null,
    private val closeHandle: (event: InventoryCloseEvent) -> Unit
) : HQContainer(54, "$key 레시피 설정", false) {

    override fun initialize(inventory: Inventory) {
        for (slot in GLASS_SLOTS) {
            HQButtonBuilder(Material.BLACK_STAINED_GLASS_PANE)
                .setDisplayName("§f")
                .build().setSlot(this, slot)
        }

        if (previousRecipe != null) {
            if (previousRecipe !is VanillaRecipe) {
                inventory.setItem(BASE_ITEM_SLOT, previousRecipe.getBaseItemView())
                previousRecipe.getMaterials().forEachIndexed { index, itemStack ->
                    inventory.setItem(MATERIAL_SLOTS[index], itemStack) }
            } else {
                previousRecipe.getMaterials().forEachIndexed { index, itemStack ->
                    inventory.setItem(VANILLA_MATERIAL_SLOTS[index], itemStack) }
            }

            inventory.setItem(RESULT_ITEM_SLOT, previousRecipe.getResultItemView())
        }
    }

    override fun onClose(event: InventoryCloseEvent) {
        closeHandle(event)
    }
}