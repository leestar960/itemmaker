package kr.hqservice.maker.core.history

import org.bukkit.Material
import org.bukkit.inventory.ItemStack
import org.bukkit.inventory.meta.ItemMeta

class PlayerItemHistory(
    private var contents: Array<ItemStack>
) {
    private class TemporaryItemData(
        val index: Int,
        val material: Material,
        val itemMeta: ItemMeta
    )
    private val removedItems = mutableMapOf<TemporaryItemData, Int>()
    var isInvalid = false
        private set

    fun removeItem(amount: Int, predicate: (ItemStack) -> Boolean) {
        var targetAmount = amount
        val filteredList = contents
        for((index, itemStack) in filteredList.withIndex()) {
            if (itemStack.type == Material.AIR || itemStack.amount <= 0 ) continue

            if (predicate.invoke(itemStack)) {
                if (itemStack.amount >= targetAmount) {
                    removedItems[TemporaryItemData(index, itemStack.type, itemStack.itemMeta!!.clone())] = targetAmount
                    itemStack.amount -= targetAmount
                    return
                } else {
                    removedItems[TemporaryItemData(index, itemStack.type, itemStack.itemMeta!!.clone())] = itemStack.amount
                    targetAmount -= itemStack.amount
                    itemStack.amount = 0
                }
            }
        }

        isInvalid = true
        throw IllegalArgumentException()
    }

    fun rollback() {
        removedItems.forEach {
            val data = it.key
            val amount = it.value
            val targetItemStack = contents[data.index]
            if (targetItemStack.type == Material.AIR) {
                targetItemStack.type = data.material
                targetItemStack.itemMeta = data.itemMeta
            }
            targetItemStack.amount += amount
        }
        removedItems.clear()
    }
}