package kr.hqservice.maker.core.command.provider

import kr.hqservice.framework.command.component.CommandContext
import kr.hqservice.framework.command.component.HQCommandArgumentProvider
import kr.hqservice.framework.global.core.component.Component
import kr.hqservice.maker.core.recipe.Recipe
import kr.hqservice.maker.core.registry.ItemRecipeRegistry
import kr.hqservice.maker.core.service.ItemRecipeService
import org.bukkit.Location

@Component
class RecipeArgumentProvider(
    private val recipeService: ItemRecipeService
) : HQCommandArgumentProvider<Recipe<*>> {
    override fun cast(context: CommandContext, string: String): Recipe<*> {
        return recipeService.findRecipe(string)!!
    }

    override fun getFailureMessage(context: CommandContext, string: String?, argumentLabel: String?): String? {
        return "&c찾을 수 없는 제작입니다."
    }

    override fun getResult(context: CommandContext, string: String?): Boolean {
        return string != null && recipeService.findRecipe(string) != null
    }

    override fun getTabComplete(context: CommandContext, location: Location?, argumentLabel: String?): List<String> {
        return recipeService.getRecipeList().map {
            it.getKey()
        }
    }
}