package kr.hqservice.maker.core.service

import kr.hqservice.framework.global.core.component.Service
import kr.hqservice.framework.view.navigator.Navigator
import kr.hqservice.framework.view.view
import kr.hqservice.maker.core.container.RecipeActionContainer
import kr.hqservice.maker.core.container.RecipeSettingContainer
import kr.hqservice.maker.core.context.BASE_ITEM_SLOT
import kr.hqservice.maker.core.context.MATERIAL_SLOTS
import kr.hqservice.maker.core.context.RESULT_ITEM_SLOT
import kr.hqservice.maker.core.hook.MMOItemHook
import kr.hqservice.maker.core.recipe.MMORecipe
import kr.hqservice.maker.core.recipe.Recipe
import kr.hqservice.maker.core.recipe.VanillaRecipe
import kr.hqservice.maker.core.registry.ItemRecipeRegistry
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.inventory.ItemStack

@Service
class ItemRecipeService(
    private val playerService: ItemRecipePlayerService,
    private val mmoItemHook: MMOItemHook,
    private val recipeRegistry: ItemRecipeRegistry
) {
    fun getRecipeList(): List<Recipe<*>> {
        return recipeRegistry.getAll()
    }

    fun findRecipe(key: String): Recipe<*>? {
        return recipeRegistry.findByKey(key)
    }

    fun createOrUpdateRecipe(recipe: Recipe<*>) {
        recipeRegistry.addRecipe(recipe)
    }

    fun removeRecipe(recipe: Recipe<*>){
        recipeRegistry.removeRecipe(recipe.getKey())
    }

    fun openRecipeView(key: String, player: Player) {
        val target = findRecipe(key) ?: return
        RecipeActionContainer(target, playerService).open(player)
    }

    fun openRecipeSettingContainer(key: String, player: Player) {
        val previousRecipe = findRecipe(key)
        RecipeSettingContainer(key, previousRecipe) {
            val inventory = it.inventory
            val baseItemStack = inventory.getItem(BASE_ITEM_SLOT)
            if (baseItemStack == null) {
                player.sendMessage("§c재료의 첫 칸은 비울 수 없습니다.")
                return@RecipeSettingContainer
            }

            val materials = mutableListOf<ItemStack>()
            for (i in MATERIAL_SLOTS)
                materials.add(inventory.getItem(i) ?: ItemStack(Material.AIR))

            val resultItemStack = inventory.getItem(RESULT_ITEM_SLOT)
            if (resultItemStack == null) {
                player.sendMessage("§c결과 아이템 칸은 비울 수 없습니다.")
                return@RecipeSettingContainer
            }

            val recipe = if (mmoItemHook.isMMOItem(baseItemStack) && mmoItemHook.isMMOItem(resultItemStack)) {
                MMORecipe(key, materials.toTypedArray(),
                    mmoItemHook.getMMOItemData(baseItemStack),
                    mmoItemHook.getMMOItemData(resultItemStack),
                    previousRecipe?.getPercent() ?: 100.0)
            } else {
                VanillaRecipe(key, materials.toTypedArray(),
                    baseItemStack,
                    resultItemStack,
                    previousRecipe?.getPercent() ?: 100.0)
            }

            recipeRegistry.addRecipe(recipe)
        }.open(player)
    }
}