package kr.hqservice.maker.core.recipe

import org.bukkit.util.io.BukkitObjectInputStream

interface IOReader<T: Recipe<*>> {
    fun read(inputStream: BukkitObjectInputStream): T
}