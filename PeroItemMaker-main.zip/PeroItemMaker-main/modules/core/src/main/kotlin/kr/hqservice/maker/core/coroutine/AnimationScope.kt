package kr.hqservice.maker.core.coroutine

import kotlinx.coroutines.*
import kr.hqservice.framework.global.core.component.Bean
import kotlin.coroutines.CoroutineContext

@Bean
class AnimationScope : CoroutineScope {
    private val supervisorJob = SupervisorJob()

    override val coroutineContext: CoroutineContext
        get() = supervisorJob + Dispatchers.Default + CoroutineName("animation_scope")

    fun getSupervisorJob(): Job {
        return supervisorJob
    }
}