package kr.hqservice.maker.core

import kr.hqservice.framework.global.core.component.Component
import kr.hqservice.framework.global.core.component.HQModule
import kr.hqservice.maker.core.registry.ItemRecipeRegistry

@Component
class PeroItemMakerBootstrap(
    private val itemRecipeRegistry: ItemRecipeRegistry
) : HQModule {
    override fun onEnable() {
        itemRecipeRegistry.loadAll()
    }
}