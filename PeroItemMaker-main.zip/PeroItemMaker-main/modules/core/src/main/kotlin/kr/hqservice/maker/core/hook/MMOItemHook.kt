package kr.hqservice.maker.core.hook

import gaya.pe.kr.fortified.data.ItemOptionType
import gaya.pe.kr.fortified.manager.FortifiedServiceManager
import io.lumine.mythic.lib.MythicLib
import io.lumine.mythic.lib.api.item.ItemTag
import io.lumine.mythic.lib.api.item.NBTItem
import kr.hqservice.framework.global.core.component.Bean
import kr.hqservice.framework.nms.extension.getNmsItemStack
import net.Indyuce.mmoitems.ItemStats
import net.Indyuce.mmoitems.MMOItems
import net.Indyuce.mmoitems.api.Type
import net.Indyuce.mmoitems.api.interaction.GemStone
import net.Indyuce.mmoitems.api.item.mmoitem.LiveMMOItem
import net.Indyuce.mmoitems.api.item.mmoitem.MMOItem
import net.Indyuce.mmoitems.api.player.PlayerData
import net.Indyuce.mmoitems.stat.data.GemSocketsData
import net.Indyuce.mmoitems.stat.data.GemstoneData
import net.Indyuce.mmoitems.util.Pair
import org.bukkit.entity.Player
import org.bukkit.inventory.ItemStack
import java.util.function.Consumer

@Bean
class MMOItemHook(
    private val mmoItems: MMOItems,
) {
    fun findByMMOItem(mmoItemData: MMOItemData): MMOItem? {
        return mmoItems.getMMOItem(mmoItemData.mmoItemType, mmoItemData.mmoItemKey)
    }

    fun findByMMOItem(mmoItem: MMOItem, player: Player): MMOItem? {
        val playerData = PlayerData.get(player.uniqueId)
        return mmoItems.getMMOItem(mmoItem.type, mmoItem.id, playerData)
    }

    fun isMMOItem(itemStack: ItemStack): Boolean {
        val tag = itemStack.getNmsItemStack().getTagOrNull() ?: return false
        return tag.hasKey("MMOITEMS_ITEM_TYPE") && tag.hasKey("MMOITEMS_ITEM_ID")
    }

    fun getMMOItemData(itemStack: ItemStack): MMOItemData {
        val tag = itemStack.getNmsItemStack().getTag()
        val typeId = tag.getString("MMOITEMS_ITEM_TYPE")
        val id = tag.getString("MMOITEMS_ITEM_ID")
        val itemOptionType = ItemOptionType.getItemOptionTypeByItem(itemStack)
        val level = FortifiedServiceManager.getInstance().getItemOptionLevel(itemOptionType, itemStack)

        return MMOItemData(Type.get(typeId)!!, id, level)
    }

    fun mmoItemEquals(itemStack: ItemStack, targetMMOItemData: MMOItemData): Boolean {
        val tag = itemStack.getNmsItemStack().getTagOrNull() ?: return false
        return if (tag.hasKey("MMOITEMS_ITEM_TYPE") && tag.hasKey("MMOITEMS_ITEM_ID")) {
            if (tag.getString("MMOITEMS_ITEM_TYPE") == targetMMOItemData.mmoItemType.id
                    && tag.getString("MMOITEMS_ITEM_ID") == targetMMOItemData.mmoItemKey) {
                val minimumLevel = targetMMOItemData.upgradeMinimumLevel
                val type = ItemOptionType.getItemOptionTypeByItem(itemStack)
                val level = FortifiedServiceManager.getInstance().getItemOptionLevel(type, itemStack)
                level >= minimumLevel
            } else false
        } else false
    }

    fun moveToNewItem(targetMMOItemData: MMOItemData, baseItemStack: ItemStack): ItemStack? {
        val targetMMOItem = findByMMOItem(targetMMOItemData) ?: return null
        return targetMMOItem.newBuilder().build()?.apply {
            val base = MythicLib.inst().version.wrapper.getNBTItem(baseItemStack)
            if (!base.hasType()) return@apply
        }
    }

    fun moveNewItemStack(player: Player, target: MMOItem, base: ItemStack): ItemStack {
        val from = fromStack(base)!!
        try {
            var gen: MMOItem = target

            val compGemstones = ArrayList<MMOItem>()
            from.extractGemstones().forEach(Consumer { pair: Pair<GemstoneData?, MMOItem> ->
                compGemstones.add(
                    pair.value
                )
            })

            val remainingStones = mutableListOf<ItemStack?>()
            for (m in compGemstones) {
                val genGemstones = gen.getData(ItemStats.GEM_SOCKETS) as GemSocketsData
                if (genGemstones.emptySlots.size == 0) {
                    remainingStones.add(m.newBuilder().build())
                    continue
                }

                val gemItem = m.newBuilder().buildNBT()
                    .addTag(ItemTag(ItemStats.SUCCESS_RATE.nbtPath, .0))
                val asGem = GemStone(player, gemItem)
                val res = asGem.applyOntoItem(gen, gen.type, "", false, true)

                if (res.type == GemStone.ResultType.SUCCESS && res.resultAsMMOItem != null) {
                    gen = res.resultAsMMOItem!!
                } else {
                    remainingStones.add(m.newBuilder().build())
                }
            }

            return gen.newBuilder().build()!!
        } catch (e: Exception) {
            e.printStackTrace()
            throw e
        }
        // Generate

    }

    private fun fromStack(item: ItemStack?): MMOItem? {
        if (item == null) {
            return null
        } else {
            val itemNBT = NBTItem.get(item)
            if (MMOItems.getType(itemNBT) != null) {
                return LiveMMOItem(item)
            }
        }
        return null
    }
}