package kr.hqservice.maker.core.recipe

import gaya.pe.kr.fortified.data.ItemOptionType
import gaya.pe.kr.fortified.manager.FortifiedServiceManager
import kr.hqservice.framework.bukkit.core.extension.displayName
import kr.hqservice.framework.bukkit.core.extension.editMeta
import kr.hqservice.framework.bukkit.core.extension.toByteArray
import kr.hqservice.framework.bukkit.core.extension.toItemArray
import kr.hqservice.framework.nms.extension.getNmsItemStack
import kr.hqservice.maker.core.hook.MMOItemData
import kr.hqservice.maker.core.hook.MMOItemHook
import net.Indyuce.mmoitems.api.item.mmoitem.MMOItem
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.inventory.ItemStack
import org.bukkit.util.io.BukkitObjectInputStream
import org.bukkit.util.io.BukkitObjectOutputStream
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

class MMORecipe(
    private val recipeKey: String,
    private val materials: Array<ItemStack>,
    private val baseMMOItemData: MMOItemData,
    private val targetMMOItemData: MMOItemData,
    private val percent: Double
) : Recipe<MMOItem>(MMORecipe) {
    companion object : IOReader<MMORecipe>, KoinComponent {
        private val mmoItemHook: MMOItemHook by inject()
        override fun read(inputStream: BukkitObjectInputStream): MMORecipe {
            val key = inputStream.readUTF()
            val base = MMOItemData.read(inputStream)
            val target = MMOItemData.read(inputStream)
            val percent = inputStream.readDouble()
            val materials = inputStream.readBytes().toItemArray()
            return MMORecipe(key, materials, base, target, percent)
        }
    }

    override fun getKey(): String {
        return recipeKey
    }

    override fun getBaseItem(): MMOItem {
        return mmoItemHook.findByMMOItem(baseMMOItemData)!!
    }

    fun getBaseItemData(): MMOItemData {
        return baseMMOItemData
    }

    override fun getBaseItemView(): ItemStack {
        var itemStack = getBaseItem().newBuilder().build()!!
        val level = getBaseItemData().upgradeMinimumLevel
        if (level > 0) {
            val type = ItemOptionType.getItemOptionTypeByItem(itemStack)
            itemStack = FortifiedServiceManager.getInstance().setItemOptionLevel(type, itemStack, level, 0)
        }
        return itemStack
    }

    override fun getResultItemView(): ItemStack {
        return mmoItemHook.findByMMOItem(targetMMOItemData)!!.newBuilder().build()!!
    }

    override fun getMaterials(): Array<ItemStack> {
        return materials.filter {
            it.type != Material.AIR
        }.toTypedArray()
    }

    @Suppress("unchecked_cast")
    override fun write(outputStream: BukkitObjectOutputStream) {
        outputStream.writeUTF(recipeKey)
        baseMMOItemData.write(outputStream)
        targetMMOItemData.write(outputStream)
        outputStream.writeDouble(percent)
        outputStream.write((materials as Array<ItemStack?>).toByteArray())
    }

    override fun getPercent(): Double {
        return percent
    }

    override fun getResult(baseItemStack: MMOItem?): MMOItem {
        if (baseItemStack == null) throw IllegalStateException("fuck")
        //MMOITEMS_GEM_STONES
        //return mmoItemHook.moveToNewItem(baseItemStack, targetMMOItemData) ?: throw IllegalArgumentException("대상 타입의 값이 올바르지 않음")
        throw UnsupportedOperationException()
    }

    fun getResult(baseItemStack: ItemStack, player: Player): ItemStack {
        return mmoItemHook.moveNewItemStack(player, mmoItemHook.findByMMOItem(targetMMOItemData)!!, baseItemStack) ?: throw IllegalArgumentException("대상 타입의 값이 올바르지 않음")
    }

    fun clone(
        materials: Array<ItemStack> = getMaterials(),
        mmoItemData: MMOItemData = baseMMOItemData,
        resultMMOItemData: MMOItemData = targetMMOItemData,
        percent: Double = getPercent()
    ) : MMORecipe {
        return MMORecipe(recipeKey, materials, mmoItemData, resultMMOItemData, percent)
    }
}