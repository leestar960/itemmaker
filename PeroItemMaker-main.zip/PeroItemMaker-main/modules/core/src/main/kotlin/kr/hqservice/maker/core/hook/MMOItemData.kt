package kr.hqservice.maker.core.hook

import net.Indyuce.mmoitems.api.Type
import java.io.ObjectInputStream
import java.io.ObjectOutputStream

data class MMOItemData(
    val mmoItemType: Type,
    val mmoItemKey: String,
    val upgradeMinimumLevel: Int
) {
    companion object {
        fun read(inputStream: ObjectInputStream): MMOItemData {
            val typeString = inputStream.readUTF()
            val keyString = inputStream.readUTF()
            val level = inputStream.readInt()
            return MMOItemData(Type.get(typeString)!!, keyString, level)
        }
    }

    fun write(outputStream: ObjectOutputStream) {
        outputStream.writeUTF(mmoItemType.id)
        outputStream.writeUTF(mmoItemKey)
        outputStream.writeInt(upgradeMinimumLevel)
    }
}