package kr.hqservice.maker.core.context

internal val GLASS_SLOTS = arrayOf(
         0, 1,                7, 8,
         9,10,               16,17,
        18,19,               25,26,
        27,28,29,30,31,32,33,34,35,
        36,37,38,39,   41,42,43,44,
        45,46,47,48,49,50,51,52,53)

internal val MATERIAL_SLOTS = arrayOf(
        3, 4, 5, 6,
        11,12,13,14,15,
        20,21,22,23,24
)

internal val VANILLA_MATERIAL_SLOTS = arrayOf(
    2, 3, 4, 5, 6,
    11,12,13,14,15,
    20,21,22,23,24
)


internal const val CONTAINER_ANIMATION_ITEM_SLOT = 33
internal const val BASE_ITEM_SLOT = 2
internal const val RESULT_ITEM_SLOT = 40
