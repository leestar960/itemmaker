package kr.hqservice.maker.core.command.node

import kr.hqservice.framework.command.component.*
import kr.hqservice.maker.core.command.RecipeCommandRoot
import kr.hqservice.maker.core.recipe.Recipe
import kr.hqservice.maker.core.service.ItemRecipeService
import org.bukkit.command.ConsoleCommandSender
import org.bukkit.entity.Player

@Command
@ParentCommand([RecipeCommandRoot::class])
class RecipeCommandNode(
    private val service: ItemRecipeService
) : HQCommandNode {
    @CommandExecutor(
        "생성",
        "해당 이름의 제작법을 생성합니다.",
        isOp = true
    )
    fun createRecipe(sender: Player, @ArgumentLabel("이름") key: String) {
        service.openRecipeSettingContainer(key, sender)
    }

    @CommandExecutor(
        "편집",
        "해당 이름의 제작법을 편집합니다.",
        isOp = true
    )
    fun editRecipe(sender: Player, @ArgumentLabel("이름") recipe: Recipe<*>) {
        service.openRecipeSettingContainer(recipe.getKey(), sender)
    }

    @CommandExecutor(
        "삭제",
        "해당 이름의 제작법을 삭제합니다.",
        isOp = true
    )
    fun removeRecipe(sender: Player, @ArgumentLabel("이름") recipe: Recipe<*>) {
        service.removeRecipe(recipe)
        sender.sendMessage("§a삭제 되었습니다.")
    }

    @CommandExecutor(
        "오픈",
        "해당 제작법을 오픈합니다.",
        isOp = true
    )
    fun openRecipe(sender: ConsoleCommandSender, @ArgumentLabel("이름") recipe: Recipe<*>, @ArgumentLabel("대상플레이어") target: Player) {
        service.openRecipeView(recipe.getKey(), target)
    }
}