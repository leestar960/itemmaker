package kr.hqservice.maker.core.command

import kr.hqservice.framework.command.component.Command
import kr.hqservice.framework.command.component.HQCommandRoot

@Command
class RecipeCommandRoot : HQCommandRoot("제작관리")