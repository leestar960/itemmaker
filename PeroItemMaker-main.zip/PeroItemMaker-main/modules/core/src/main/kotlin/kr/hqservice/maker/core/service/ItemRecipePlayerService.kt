package kr.hqservice.maker.core.service

import kr.hqservice.framework.global.core.component.Service
import kr.hqservice.framework.nms.extension.getNmsItemStack
import kr.hqservice.maker.core.history.PlayerItemHistory
import kr.hqservice.maker.core.history.PlayerItemHistoryFactory
import kr.hqservice.maker.core.hook.MMOItemHook
import kr.hqservice.maker.core.recipe.MMORecipe
import kr.hqservice.maker.core.recipe.Recipe
import kr.hqservice.maker.core.recipe.VanillaRecipe
import org.bukkit.entity.Player
import org.bukkit.inventory.ItemStack

@Service
class ItemRecipePlayerService(private val mmoItemHook: MMOItemHook) {
    fun applyRecipe(player: Player, recipe: Recipe<*>): ItemStack? {
        var resultItemStack: ItemStack? = null
        val history = when (recipe) {
            is MMORecipe -> {
                onHistory(player) {
                    removeItem(1) {
                        if (mmoItemHook.mmoItemEquals(it, recipe.getBaseItemData())) {
                            resultItemStack = recipe.getResult(it, player)
                            true
                        } else false
                    }

                    recipe.getMaterials().forEach {
                        removeItem(it.amount, it::isSimilar)
                    }
                }
            }

            is VanillaRecipe -> {
                resultItemStack = recipe.getResult(null).clone()

                onHistory(player) {
                    recipe.getMaterials().forEach {
                        removeItem(it.amount, it::isSimilar)
                    }
                }
            }
        }

        return if (history.isInvalid) {
            history.rollback()
            null
        } else {
            resultItemStack
        }
    }

    private fun onHistory(player: Player, scope: PlayerItemHistory.() -> Unit): PlayerItemHistory {
        val history = PlayerItemHistoryFactory.of(player)
        try {
            history.scope()
        } catch (_: Exception) {}
        return history
    }
}