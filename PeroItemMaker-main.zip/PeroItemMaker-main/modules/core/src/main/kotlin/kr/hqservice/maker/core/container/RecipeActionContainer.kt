package kr.hqservice.maker.core.container

import dev.lone.itemsadder.api.CustomStack
import dev.lone.itemsadder.api.FontImages.FontImageWrapper
import kotlinx.coroutines.*
import kr.hqservice.framework.coroutine.UUIDCoroutineContextElement
import kr.hqservice.framework.coroutine.extension.BukkitMain
import kr.hqservice.framework.coroutine.extension.coroutineContext
import kr.hqservice.framework.inventory.button.HQButtonBuilder
import kr.hqservice.framework.inventory.container.HQContainer
import kr.hqservice.framework.nms.extension.virtual
import kr.hqservice.maker.core.context.*
import kr.hqservice.maker.core.context.BASE_ITEM_SLOT
import kr.hqservice.maker.core.context.CONTAINER_ANIMATION_ITEM_SLOT
import kr.hqservice.maker.core.context.MATERIAL_SLOTS
import kr.hqservice.maker.core.context.RESULT_ITEM_SLOT
import kr.hqservice.maker.core.context.VANILLA_MATERIAL_SLOTS
import kr.hqservice.maker.core.coroutine.AnimationScope
import kr.hqservice.maker.core.recipe.Recipe
import kr.hqservice.maker.core.recipe.VanillaRecipe
import kr.hqservice.maker.core.service.ItemRecipePlayerService
import org.bukkit.Material
import org.bukkit.Sound
import org.bukkit.entity.Player
import org.bukkit.event.inventory.InventoryClickEvent
import org.bukkit.event.inventory.InventoryCloseEvent
import org.bukkit.inventory.Inventory
import org.bukkit.inventory.ItemStack
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

class RecipeActionContainer(
    private val recipe: Recipe<*>,
    private val service: ItemRecipePlayerService,
) : HQContainer(54, "§f" + FontImageWrapper("pero_item_maker:gui_default").applyPixelsOffset(-7)) {
    companion object : KoinComponent {
        private val animationScope: AnimationScope by inject()
        private val voidButton by lazy {
            CustomStack.getInstance("pero_item_maker:button_void")?.itemStack ?: ItemStack(Material.STONE)
        }
    }

    private var isClosed = false

    override fun initialize(inventory: Inventory) {
        if (recipe !is VanillaRecipe) {
            inventory.setItem(BASE_ITEM_SLOT, recipe.getBaseItemView())
            recipe.getMaterials().forEachIndexed { index, itemStack ->
                inventory.setItem(MATERIAL_SLOTS[index], itemStack) }
        } else {
            recipe.getMaterials().forEachIndexed { index, itemStack ->
                inventory.setItem(VANILLA_MATERIAL_SLOTS[index], itemStack) }
        }

        HQButtonBuilder(voidButton)
            .setDisplayName("<g:c0eb81>&n 제작 시작 </g:f29b22>")
            .setClickFunction {
                val player = it.getWhoClicked()
                val result = inventory.getItem(RESULT_ITEM_SLOT)
                if (result != null && result.type != Material.AIR) {
                    player.playSound(player.location, Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 0.7f)
                    player.sendMessage("§c먼저 이 전의 결과 아이템을 클릭하여 가져가주세요.")
                    return@setClickFunction
                }
                val uuid = player.uniqueId
                if (animationScope.getSupervisorJob().children.any { job ->
                        job.coroutineContext[UUIDCoroutineContextElement]?.uuid == uuid
                    }) return@setClickFunction
                animationScope.launch(UUIDCoroutineContextElement(uuid)) {
                    if (isClosed) return@launch
                    player.playSound(player.location, Sound.UI_BUTTON_CLICK, 0.4f, 1.4f)
                    setTitle("§f" + FontImageWrapper("pero_item_maker:gui_press").applyPixelsOffset(-7), player)
                    delay(100)
                    for (i in 1..16) {
                        player.playSound(player.location, Sound.BLOCK_NOTE_BLOCK_GUITAR, 0.4f, i * 0.1f + 0.3f)
                        setTitle("§f" + FontImageWrapper("pero_item_maker:gui_frame_$i").applyPixelsOffset(-7), player)
                        delay(50)
                    }
                    withContext(Dispatchers.BukkitMain) {
                        val result = service.applyRecipe(it.getWhoClicked(), recipe)
                        if (result != null) {
                            setTitle("§f" + FontImageWrapper("pero_item_maker:gui_frame_success").applyPixelsOffset(-7), player)
                            inventory.setItem(RESULT_ITEM_SLOT, result)
                            player.playSound(player.location, Sound.ENTITY_PLAYER_LEVELUP, 0.4f, 1.7f)
                        } else {
                            player.sendMessage("§c재료가 부족합니다.")
                            setTitle("§f" + FontImageWrapper("pero_item_maker:gui_frame_fail").applyPixelsOffset(-7), player)
                            player.playSound(player.location, Sound.ITEM_SHIELD_BREAK, 0.4f, 1.4f)
                        }
                    }
                }
            }.build().setSlot(this, CONTAINER_ANIMATION_ITEM_SLOT)
    }

    private suspend fun setTitle(title: String, player: Player) {
        player.virtual {
            inventory { setTitle(title) }
        }.join()
    }

    override fun onClick(event: InventoryClickEvent) {
        if (event.rawSlot == RESULT_ITEM_SLOT) {
            val item = event.currentItem ?: return
            if (item.type != Material.AIR) {
                event.isCancelled = true
                val player = event.whoClicked as Player
                player.playSound(player.location, Sound.ITEM_ARMOR_EQUIP_LEATHER, 0.7f, 1.4f)
                player.inventory.addItem(item.clone())
                item.amount = 0
            }
        }
    }

    override fun onClose(event: InventoryCloseEvent) {
        isClosed = true
        animationScope.getSupervisorJob().children.firstOrNull {
            it.coroutineContext[UUIDCoroutineContextElement]?.uuid == event.player.uniqueId
        }?.cancel()?.apply {
            event.player.closeInventory()
        }
        val result = event.inventory.getItem(RESULT_ITEM_SLOT)
        if (result != null && result.type != Material.AIR)
            event.player.inventory.addItem(result)
    }
}