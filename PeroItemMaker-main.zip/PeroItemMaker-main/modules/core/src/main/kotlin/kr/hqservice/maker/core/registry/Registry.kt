package kr.hqservice.maker.core.registry

import kr.hqservice.framework.global.core.component.Bean

typealias Registry = Bean