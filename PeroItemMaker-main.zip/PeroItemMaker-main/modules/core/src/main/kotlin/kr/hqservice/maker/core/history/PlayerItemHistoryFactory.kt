package kr.hqservice.maker.core.history

import org.bukkit.entity.Player

object PlayerItemHistoryFactory {
    fun of(player: Player): PlayerItemHistory {
        return PlayerItemHistory(player.inventory.storageContents.filter { it != null && !it.type.isAir }.toTypedArray())
    }
}