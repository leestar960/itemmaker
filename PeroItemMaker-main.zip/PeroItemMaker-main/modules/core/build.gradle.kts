plugins {
    id("hq.shared")
}

dependencies {
    compileOnly(libs.spigot.api)
    compileOnly(framework.core)
    compileOnly(framework.nms)
    compileOnly(framework.command)
    compileOnly(framework.inventory)
    compileOnly(libs.mmo.item)
    compileOnly(libs.mmo.lib)
    compileOnly(libs.londev.ia)

    compileOnly(fileTree("${rootProject.projectDir}/libs/FortifiedPlugin-1.0-SNAPSHOT.jar"))

    api(project(":modules:api"))
}