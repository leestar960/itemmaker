group = "kr.hqservice"
version = "1.0-SNAPSHOT"